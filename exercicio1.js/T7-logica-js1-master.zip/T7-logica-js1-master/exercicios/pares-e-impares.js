/*
Mostre no console os números pares entre 1 e 10, e os número ímpares entre 11 e 20, 
usando a estrutura de repetição "while".
*/

