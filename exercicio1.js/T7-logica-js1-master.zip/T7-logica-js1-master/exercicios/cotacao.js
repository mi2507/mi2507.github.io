// Crie uma função para converter bitcoin em reais, dada uma quantia e uma cotação.
