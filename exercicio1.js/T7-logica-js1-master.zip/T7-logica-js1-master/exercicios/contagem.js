var temporizador = setInterval(contagem,1000);
var tempo = 0;

function contagem(){
    tempo++;
    console.log(tempo);
}