/*
Função chamada 'calculadora', que receba um dos quatro operadores matemáticos como parâmetro (+, -, *, /).
Essa função deverá receber outra função, que receba dois números como parâmetros;
Esses números serão os operandos das quatro operações matemáticas;
Na segunda função, crie retornos para cada uma das quatro operações matemáticas possíveis, da seguinte forma:
"O resultado da operação: [numero1] [operador] [numero2] é igual a [resultado]"
*/

// Passo 1: criar a soma

// Passo 2: criar a substração

// Passo 3: criar a multiplicação

// Passo 4: criar a divisão

// Passo 5: criar aviso caso o usuário não coloque nenhum dos 4 operadores possíveis;
