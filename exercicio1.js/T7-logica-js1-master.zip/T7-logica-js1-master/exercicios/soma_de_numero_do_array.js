var numeros = [2,2,3,11];
var total = 0;

for(var i = 0; i < numeros.length; i++){
    total = total + numeros[i];
}

console.log(total)