function condicao(x) {
	switch(x){
		case 1:
        console.log('Ana');
        break;
		case 2:
        console.log('Bia');
        break;
		case 3:
        console.log('Carla');
        break;
		default:
		console.log('gatinho');
    }
}