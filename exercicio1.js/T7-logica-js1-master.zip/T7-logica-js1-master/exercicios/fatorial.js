/*
O fatorial de um número é calculado pela multiplicação 
desse número por todos os seus antecessores até chegar ao número 1.
Crie uma função que seja capaz de apresentar o fatorial do número que recebe por parâmetro. 
*/