/*
Usando a estrutura SWITH, crie uma função que transforme quatro cores passadas por parâmetro em formato 'string', para os equivalentes hexadecimais.
Se a cor passada não estiver entre as que você selecionou, mostre a seguinte frase "Não temos o equivalente hexadecimal para [cor]".
*/