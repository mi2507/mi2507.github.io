var numeros = 0

// exemplo FOR
for(var i = 0; i < 10; i++){
    console.log(numeros);
    numeros++
}
console.log("Saiu do 'for'")


// exemplo WHILE
while (numeros < 20){
    console.log(numeros);
    numeros++
}
console.log("Acabou o 'while'!")

