/*
Crie uma função que identifique palíndromos - palavras que podem ser lidas de trás para frente, continuando a mesma palavra.
Exemplos: ana, ovo, radar, osso 
*/