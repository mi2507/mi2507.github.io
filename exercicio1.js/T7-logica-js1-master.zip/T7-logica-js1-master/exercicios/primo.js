/* 
Crie uma função indique se o número passado por parâmetro é primo ou não. 
Lembrando: todo número primo é apenas divisível por 1 e por ele mesmo.
*/
