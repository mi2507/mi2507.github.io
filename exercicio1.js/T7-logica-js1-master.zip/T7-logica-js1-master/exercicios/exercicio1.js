// Declare uma variável chamada "meunumero", sem valor.
?

// Após declarada, atribua o seu número da sorte à variavel "meunumero".
?

// Declare uma nova variável chamada "soma", e adicione a adição de dois números.
?

// Atribua à variável "soma" todo o valor dela, somando 1, usando o operador de soma abreviado.
?

// Atribua à variável "soma" todo o valor dela, multiplicando por 3, usando o operador de multiplicação abreviado.
?

// Qual é o valor da variável "soma" até aqui?
?

// Declare uma variável chamada "turma7", atribuindo à ela o valor booleano que representa "verdadeiro".
?

// Declare uma variável chamada "comida" que recebe um array com strings referentes ao que você comeu hoje.
?

// Digite a instrução que imprime o valor do último item da lista.
?

// Digite o código que verifica se a variável "soma' é igual a variável "meunumeror" (testando também o tipo).
?

// Digite o código que verifica se a variável "meunumero" é menor ou igual à variável "soma".
?

// Crie uma função chamada "divisao" que receba como parâmetro dois números, e retorne o resultado da divisão entre eles.
?

// Invoque a função criada acima, passando os parâmetros 30 e 2.
?