// Diferença entre FOR e WHILE

var contagem = 0;

while(contagem < 10) {
    contagem++;
    console.log(contagem);
}

for(var i = 0; i < 10; i++){
    contagem++;
    console.log(contagem);
}