// Vamos adicionar pessoas no elevador da Estação Hack!
var elevador = {
    marca: "Schindler",
    pessoasDentro: 0,
    limiteSuportado: 13,
};

/* 
Crie um método que adicione pessoas aos poucos no elevador.
Por parâmetro, ele deverá receber um número de pessoas que entrarão, e retornar uma frase que indique quantas pessoas já estão dentro do elevador. 
Se o elevador estiver cheio, o método deverá retornar a frase que indique que não cabem mais pessoas;
Se ainda houver espaço, o método deverá retornar uma frase indicando quantas pessoas estão dentro do elevador e quantas ainda podem entrar.
Se couber apenas mais uma pessoa no elevador, retorna a frase no singular: "Só cabe mais uma pessoa no elevador!";
*/

// Passo 1: criar a função mais simples para adicionar pessoas

// Passo 2: criar a condição (if) de elevador cheio

// Passo 3: criar outra condição (else) para quando ainda couber 1 pessoa.

// Pesso 4: adicionar a informação de quantas pessoas ainda cabem na condição final (else)

// Passo 5: refatorar o código

// Agora, adicione pessoas para testar todas as condições!

// Crie um método para remover pessoas.

