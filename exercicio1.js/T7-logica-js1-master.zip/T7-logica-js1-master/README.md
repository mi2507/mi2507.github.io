# Semana 5 - Lógica de programação e Javascript 1

## O objetivo dessa semana é apresentar o raciocínio lógico por trás da programação, com uma introdução à sintaxe javascript.

### Slides (sem respostas):
https://docs.google.com/presentation/d/1_bXTYXHo4i6h2lRCaUUZ9_1fkOGR6TFWGKaMNWbRV-M/edit?usp=sharing

### Slides (com respostas):
https://docs.google.com/presentation/


#### Segunda-feira (08/04)
* Introdução
* Desmistificando o conceito de lógica
* Video: 
* O que é um algoritmo
* Pseudocódigo
    * Atividade: dicionário
* Fluxograma
    * Atividade: primeiros níveis do jogo Human Resource Machine

#### Terça-feira (09/04)
* Introdução a sintaxe Javascript
* Variáveis e tipos de dados
   
#### Quarta-feira (10/04)
* Operadores aritméticos e relacionais
* Funções
* Operadores lógicos
* Condições

#### Quinta-feira (11/04)
* Exercícios

#### Sexta-feira (12/04)
* Revisão 
